import React from 'react'

export default function trend() {
  return (
    <div>trend</div>
  )
}
