import axios from "axios";

const baseURL = "https://api.nexon.co.kr/fifaonline4/v1.0";
const Static_URL = "https://static.api.nexon.co.kr/fifaonline4/latest/";
const API_KEY =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJYLUFwcC1SYXRlLUxpbWl0IjoiMjAwMDA6MTAiLCJhY2NvdW50X2lkIjoiMTIyNDg0MzM5MyIsImF1dGhfaWQiOiI0IiwiZXhwIjoxNzU3NTU5NzUxLCJpYXQiOjE2OTQ0ODc3NTEsIm5iZiI6MTY5NDQ4Nzc1MSwic2VydmljZV9pZCI6IjQzMDAxMTQ4MSIsInRva2VuX3R5cGUiOiJBY2Nlc3NUb2tlbiJ9.xxFioUA4t272ybR9GLyMP5mN20UaqpFcxSZXStwRvuY";

const dataInput = (state, action) => {
  switch (action.type) {
    case "nickname":
      return {
        ...state,
        nickname: action.d.nickname,
        level: action.d.level,
        accessId: action.d.accessId,
      };
    case "rating":
      return {
        ...state,
        rating: action.d2,
      };
    case "record":
      return {
        ...state,
        record: action.d3,
      };
    default:
      return state;
  }
};

const baseApi = axios.create({
  baseURL: baseURL,
  headers: { Authorization: API_KEY },
});

const staticTypes = ["matchtype", "spid", "seasonid", "spposition", "division"];

const staticFetch = async (statics) => {
  if (!staticTypes.includes(statics)) {
    console.error(`Invalid fetch type: ${statics}`);
    return null;
  }
  try {
    const response = await axios.get(`${Static_URL}${statics}.json`);
    return response.data;
  } catch (error) {
    console.error(`Error fetching ${statics}.json:`, error);
    return null;
  }
};

export { baseApi, dataInput, staticFetch };
