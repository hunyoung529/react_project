import React, { useReducer, useState } from "react";
import { baseApi, dataInput } from "./Instance";

function Home() {
  const [data, dispatch] = useReducer(dataInput, []);
  const [nickname, setNickname] = useState("");
  const [selectedMatchDetail, setSelectedMatchDetail] = useState(null);
  const [selectedMatchId, setSelectedMatchId] = useState(null);

  const matchTypes = {
    30: "리그 친선",
    40: "클래식 1on1",
    50: "공식경기",
    52: "감독모드",
    60: "공식 친선",
    204: "볼타 친선",
    214: "볼타 공식",
    224: "볼타 AI대전",
    234: "볼타 커스텀",
  };

  const controllerType = {
    gamepad: "게임패드",
    keyboard: "키보드",
  };
  function formatDate(achievedDate) {
    if (!achievedDate) return "";

    const date = new Date(achievedDate);
    const formattedDate = date.toLocaleString("ko-KR", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });

    const hour = date.getHours().toString().padStart(2, "0");
    const minute = date.getMinutes().toString().padStart(2, "0");

    return `${formattedDate} ${hour}시 ${minute}분`;
  }

  const renderDetailRow = (label, team1Data, team2Data) => (
    <div className="detailRow">
      <p>{label}</p>
      <p>{team1Data}</p>
      <p>{team2Data}</p>
    </div>
  );
  const fetchUserInfo = async () => {
    const nicknameCheck = nickname.trim();

    if (!nicknameCheck) {
      alert("구단주명을 입력해주세요.");
      return;
    }

    try {
      const userRes = await baseApi.get(`/users?nickname=${nicknameCheck}`);
      const { accessId, nickname, level } = userRes.data;

      // 여기서 바로 dispatch를 사용해 nickname과 level을 저장합니다.
      dispatch({ type: "nickname", d: { nickname, level } });

      // accessId를 사용하여 rating과 record를 호출합니다.
      fetchMaxDivision(accessId);
    } catch (error) {
      console.error("Error fetching data:", error);
      alert("데이터를 가져오는 데 실패했습니다.");
    }
  };

  const fetchMaxDivision = async (accessId) => {
    try {
      const ratingRes = await baseApi.get(`/users/${accessId}/maxdivision`);
      dispatch({ type: "rating", d2: ratingRes.data });
      const recordRes = await baseApi.get(
        `/users/${accessId}/matches?matchtype=50&offset=0&limit=5`
      );
      dispatch({ type: "record", d3: recordRes.data });
    } catch (error) {
      console.error("Error fetching max division:", error);
    }
  };

  const fetchMatchDetail = async (id) => {
    try {
      const response = await baseApi.get(`/matches/${id}`);
      setSelectedMatchDetail(response.data);
    } catch (error) {
      console.error("Error fetching match detail:", error);
    }
  };

  console.log(selectedMatchDetail);
  return (
    <>
      <div>
        <input
          type="text"
          value={nickname}
          onChange={(e) => setNickname(e.target.value)}
          placeholder="구단주명"
        />
        <button onClick={fetchUserInfo}>검색</button>
        <div>
          {data.nickname && (
            <>
              <p>구단주명: {data.nickname}</p>
              <p>레벨: {data.level}</p>
              {data.rating && (
                <div className="top-rating">
                  <p>
                    {matchTypes[data.rating["0"]?.matchType]}
                    레이팅:
                    {data.rating["0"]?.division}점 달성일:
                    {formatDate(data.rating["0"]?.achievementDate)}
                  </p>
                  <p>
                    {matchTypes[data.rating["1"]?.matchType]}
                    레이팅:
                    {data.rating["1"]?.division}점 달성일:
                    {formatDate(data.rating["1"]?.achievementDate)}
                  </p>
                </div>
              )}
              <div>
                {data.record &&
                  data.record.map((id, index) => (
                    <div key={index}>
                      <p>{id}</p>
                      <button
                        onClick={() => {
                          setSelectedMatchDetail(null);
                          fetchMatchDetail(id);
                          setSelectedMatchId(id);
                        }}
                      >
                        자세히보기
                      </button>
                      {selectedMatchId === id && selectedMatchDetail && (
                        <div className="matchDetail">
                          <div>
                            <button>요약</button>
                            <button>슈팅</button>
                            <button>패스</button>
                            <button>수비</button>
                          </div>
                          <div className="header">
                            <p>기록</p>
                            <p>
                              {selectedMatchDetail.matchInfo[0].nickname}{" "}
                              {
                                controllerType[
                                  selectedMatchDetail.matchInfo[0].matchDetail
                                    .controller
                                ]
                              }
                            </p>
                            <p>
                              {selectedMatchDetail.matchInfo[1].nickname}{" "}
                              {
                                controllerType[
                                  selectedMatchDetail.matchInfo[1].matchDetail
                                    .controller
                                ]
                              }
                            </p>
                          </div>
                          {renderDetailRow(
                            "결과",
                            `${selectedMatchDetail.matchInfo[0].matchDetail.matchResult}`,
                            `${selectedMatchDetail.matchInfo[1].matchDetail.matchResult}`
                          )}
                          {renderDetailRow(
                            "파울",
                            `${selectedMatchDetail.matchInfo[0].matchDetail.foul}회`,
                            `${selectedMatchDetail.matchInfo[1].matchDetail.foul}회`
                          )}
                          {renderDetailRow(
                            "점유율",
                            `${selectedMatchDetail.matchInfo[0].matchDetail.possession}%`,
                            `${selectedMatchDetail.matchInfo[1].matchDetail.possession}%`
                          )}
                          {renderDetailRow(
                            "옐로우카드",
                            `${selectedMatchDetail.matchInfo[0].matchDetail.yellowCards}장`,
                            `${selectedMatchDetail.matchInfo[1].matchDetail.yellowCards}장`
                          )}
                          {renderDetailRow(
                            "레드카드",
                            `${selectedMatchDetail.matchInfo[0].matchDetail.redCards}장`,
                            `${selectedMatchDetail.matchInfo[1].matchDetail.redCards}장`
                          )}
                          {renderDetailRow(
                            "코너킥",
                            `${selectedMatchDetail.matchInfo[0].matchDetail.cornerKick}`,
                            `${selectedMatchDetail.matchInfo[1].matchDetail.cornerKick}`
                          )}
                        </div>
                      )}
                    </div>
                  ))}
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
}

export default Home;
