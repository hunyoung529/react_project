import React, { createContext, useState } from "react";
import { baseApi, dataInput as inputData } from "./component/Instance";

export const FifaContext = createContext();
export const dataInput = inputData;

function Context({ children }) {
  const [nickname, setNickname] = useState(null);

  return (
    <FifaContext.Provider value={{ baseApi, inputData, nickname, setNickname }}>
      {children}
    </FifaContext.Provider>
  );
}

export default Context;
