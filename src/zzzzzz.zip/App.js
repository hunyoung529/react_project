import "./App.scss";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import Context from "./Context";
import Home from "./component/Home";
import Record from "./component/Record";
import { FifaContext } from "./Context";
import { useContext } from "react";

function App() {
  const { nickname } = useContext(FifaContext); // nickname 값을 가져옵니다

  return (
    <Context>
      <BrowserRouter basename="react_project">
        <header></header>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/Record" element={<Record />} />
        </Routes>
        <footer>
          <Link to="/">메인</Link>
          {nickname && (
            <>
              <Link to="/trend">트렌드</Link>
              <Link to="/Record">기록</Link>
            </>
          )}
          <Link to="/setting">설정</Link>
        </footer>
      </BrowserRouter>
    </Context>
  );
}

export default App;
