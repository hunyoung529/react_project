import React, { createContext } from "react";
import { baseApi, dataInput  } from "./component/Instance";

export const FifaContext = createContext();

function Context({ children }) {
  return (
    <FifaContext.Provider value={{ baseApi, dataInput }}>
      {children}
    </FifaContext.Provider>
  );
}

export default Context;
