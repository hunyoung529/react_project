import React, { useReducer, useState } from "react";
import { baseApi, dataInput } from "./Instance";

function Home() {
  const [data, dispatch] = useReducer(dataInput, {});
  const [nickname, setNickname] = useState("");

  const fetchUserInfo = async () => {
    const nicknameCheck = nickname.trim();

    if (!nicknameCheck) {
      alert("구단주명을 입력해주세요.");
      return;
    }

    try {
      const userRes = await baseApi.get(`/users?nickname=${nicknameCheck}`);
      dispatch({ type: "nickname", d: userRes.data });

      const accessId = userRes.data.accessId;

      const recordRes = await baseApi.get(`/users/${accessId}/maxdivision`);

      dispatch({ type: "record", d2: recordRes.data });
    } catch (error) {
      console.error("Error fetching data:", error);
      alert("데이터를 가져오는 데 실패했습니다.");
    }
  };

  console.log(data);

  return (
    <>
      <div>
        <input
          type="text"
          value={nickname}
          onChange={(e) => setNickname(e.target.value)}
          placeholder="구단주명"
        />
        <button onClick={fetchUserInfo}>검색</button>
        <div>
          {data && (
            <>
              <p>구단주명: {data.nickname}</p>
              <p>레벨: {data.level}</p>
              <p>{data.accessId}</p>
              <div className="top-rating">
                <p>{data.division}</p>
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
}

export default Home;
