import "./App.css";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import Context from "./Context";
import Home from "./component/Home";

function App() {
  return (
    <Context>
      <BrowserRouter basename="react_project">
        <header></header>
        <Routes>
          <Route path="/" element={<Home />} />
        </Routes>
        {/* <footer>
          <Link to="/">메인</Link>
          <Link to="/trend">트렌드</Link>
          <Link to="/search">검색</Link>
          <Link to="/setting">설정</Link>
        </footer> */}
      </BrowserRouter>
    </Context>
  );
}

export default App;
