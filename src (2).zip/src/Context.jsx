import React, { createContext, useState } from "react";
import { baseApi, dataInput, staticFetch } from "./component/Instance";

export const FifaContext = createContext();

function Context({ children }) {
  return (
    <FifaContext.Provider value={{ baseApi, dataInput, staticFetch }}>
      {children}
    </FifaContext.Provider>
  );
}

export default Context;
