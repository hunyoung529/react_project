import React, { useReducer, useState } from "react";
import { baseApi, dataInput } from "./Instance";

function Home() {
  const [data, dispatch] = useReducer(dataInput, []);
  const [nickname, setNickname] = useState("");

  const fetchUserData = async () => {
    const nicknameCheck = nickname.trim();

    if (!nicknameCheck) {
      alert("구단주명을 입력해주세요.");
      return;
    }
    try {
      const res = await baseApi.get(`/users?nickname=${nicknameCheck}`);

      if (!res.data || !res.data.nickname) {
        alert("유효하지 않은 구단주명입니다.");
        return;
      }

      dispatch({ type: "nickname", d: res });
    } catch (error) {
      console.error("Error fetching user data:", error);
      alert("유효하지 않은 구단주명입니다.");
    }
  };

  const handleSearch = () => {
    if (!nickname.trim()) {
      alert("구단주명을 입력하세요");
      return;
    }
    fetchUserData();
  };
  return (
    <>
      <div>
        <input
          type="text"
          value={nickname}
          onChange={(e) => setNickname(e.target.value)}
          placeholder="구단주명"
        />
        <button onClick={handleSearch}>검색</button>
        <div>
          {data && (
            <>
              <p>구단주명: {data["nickname"]}</p>
              <p>레벨: {data["level"]}</p>
              <p>{data["accessId"]}</p>
            </>
          )}
        </div>
        <div className="max-div">
          <p></p>
          <p></p>
        </div>
      </div>
    </>
  );
}

export default Home;
